﻿
namespace konvertorvaluti
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.rub1 = new System.Windows.Forms.RadioButton();
            this.usd1 = new System.Windows.Forms.RadioButton();
            this.eur1 = new System.Windows.Forms.RadioButton();
            this.funt1 = new System.Windows.Forms.RadioButton();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.rub2 = new System.Windows.Forms.RadioButton();
            this.usd2 = new System.Windows.Forms.RadioButton();
            this.eur2 = new System.Windows.Forms.RadioButton();
            this.funt2 = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(73, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "У меня есть";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(431, 66);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Я хочу пробрести";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.pictureBox4, 5, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox3, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.usd1, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.eur1, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.funt1, 5, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.rub1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 3, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(73, 108);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 64F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(286, 88);
            this.tableLayoutPanel1.TabIndex = 3;
            this.tableLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.tableLayoutPanel1_Paint);
            // 
            // rub1
            // 
            this.rub1.AutoSize = true;
            this.rub1.Location = new System.Drawing.Point(3, 3);
            this.rub1.Name = "rub1";
            this.rub1.Size = new System.Drawing.Size(48, 17);
            this.rub1.TabIndex = 1;
            this.rub1.TabStop = true;
            this.rub1.Text = "RUB";
            this.rub1.UseVisualStyleBackColor = true;
            // 
            // usd1
            // 
            this.usd1.AutoSize = true;
            this.usd1.Location = new System.Drawing.Point(76, 3);
            this.usd1.Name = "usd1";
            this.usd1.Size = new System.Drawing.Size(48, 17);
            this.usd1.TabIndex = 0;
            this.usd1.TabStop = true;
            this.usd1.Text = "USD";
            this.usd1.UseVisualStyleBackColor = true;
            // 
            // eur1
            // 
            this.eur1.AutoSize = true;
            this.eur1.Location = new System.Drawing.Point(142, 3);
            this.eur1.Name = "eur1";
            this.eur1.Size = new System.Drawing.Size(48, 17);
            this.eur1.TabIndex = 2;
            this.eur1.TabStop = true;
            this.eur1.Text = "EUR";
            this.eur1.UseVisualStyleBackColor = true;
            // 
            // funt1
            // 
            this.funt1.AutoSize = true;
            this.funt1.Location = new System.Drawing.Point(215, 3);
            this.funt1.Name = "funt1";
            this.funt1.Size = new System.Drawing.Size(54, 17);
            this.funt1.TabIndex = 3;
            this.funt1.TabStop = true;
            this.funt1.Text = "FUNT";
            this.funt1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 6;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel3.Controls.Add(this.rub2, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.usd2, 3, 0);
            this.tableLayoutPanel3.Controls.Add(this.eur2, 4, 0);
            this.tableLayoutPanel3.Controls.Add(this.funt2, 5, 0);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox5, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox6, 3, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox7, 4, 1);
            this.tableLayoutPanel3.Controls.Add(this.pictureBox8, 5, 1);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(431, 105);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 61F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(248, 88);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // rub2
            // 
            this.rub2.AutoSize = true;
            this.rub2.Location = new System.Drawing.Point(3, 3);
            this.rub2.Name = "rub2";
            this.rub2.Size = new System.Drawing.Size(48, 17);
            this.rub2.TabIndex = 1;
            this.rub2.TabStop = true;
            this.rub2.Text = "RUB";
            this.rub2.UseVisualStyleBackColor = true;
            // 
            // usd2
            // 
            this.usd2.AutoSize = true;
            this.usd2.Location = new System.Drawing.Point(68, 3);
            this.usd2.Name = "usd2";
            this.usd2.Size = new System.Drawing.Size(48, 17);
            this.usd2.TabIndex = 0;
            this.usd2.TabStop = true;
            this.usd2.Text = "USD";
            this.usd2.UseVisualStyleBackColor = true;
            // 
            // eur2
            // 
            this.eur2.AutoSize = true;
            this.eur2.Location = new System.Drawing.Point(132, 3);
            this.eur2.Name = "eur2";
            this.eur2.Size = new System.Drawing.Size(48, 17);
            this.eur2.TabIndex = 2;
            this.eur2.TabStop = true;
            this.eur2.Text = "EUR";
            this.eur2.UseVisualStyleBackColor = true;
            // 
            // funt2
            // 
            this.funt2.AutoSize = true;
            this.funt2.Location = new System.Drawing.Point(186, 3);
            this.funt2.Name = "funt2";
            this.funt2.Size = new System.Drawing.Size(54, 17);
            this.funt2.TabIndex = 3;
            this.funt2.TabStop = true;
            this.funt2.Text = "FUNT";
            this.funt2.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(73, 230);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(286, 20);
            this.textBox1.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(431, 230);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(248, 20);
            this.textBox2.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(360, 282);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Посчитать";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = global::konvertorvaluti.Properties.Resources.rub;
            this.pictureBox5.Location = new System.Drawing.Point(3, 30);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(59, 55);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 4;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = global::konvertorvaluti.Properties.Resources.dol;
            this.pictureBox6.Location = new System.Drawing.Point(68, 30);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(58, 55);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = global::konvertorvaluti.Properties.Resources.eu;
            this.pictureBox7.Location = new System.Drawing.Point(132, 30);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(48, 55);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 6;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = global::konvertorvaluti.Properties.Resources.funt;
            this.pictureBox8.Location = new System.Drawing.Point(186, 30);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(62, 55);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8.TabIndex = 7;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::konvertorvaluti.Properties.Resources.eu;
            this.pictureBox4.Location = new System.Drawing.Point(215, 27);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(67, 58);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = global::konvertorvaluti.Properties.Resources.funt;
            this.pictureBox3.Location = new System.Drawing.Point(142, 27);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(67, 58);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 8;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::konvertorvaluti.Properties.Resources.rub;
            this.pictureBox1.Location = new System.Drawing.Point(3, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(67, 58);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::konvertorvaluti.Properties.Resources.dol;
            this.pictureBox2.Location = new System.Drawing.Point(76, 27);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 58);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(389, 135);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 26);
            this.label3.TabIndex = 8;
            this.label3.Text = "->\r\n<-";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.tableLayoutPanel3);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.RadioButton usd1;
        private System.Windows.Forms.RadioButton rub1;
        private System.Windows.Forms.RadioButton eur1;
        private System.Windows.Forms.RadioButton funt1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.RadioButton rub2;
        private System.Windows.Forms.RadioButton usd2;
        private System.Windows.Forms.RadioButton eur2;
        private System.Windows.Forms.RadioButton funt2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label3;
    }
}

