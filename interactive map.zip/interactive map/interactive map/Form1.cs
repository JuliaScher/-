﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace interactive_map
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            panel2.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            label2.Text = "Finish";            
            label3.Text = "Final";
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 1";
            label3.Text = "Особенности: \n Стенд питья \n Энергетические батончики \n Туалет \n Медицинский пункт";

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 2";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void panel2_Click(object sender, PaintEventArgs e)
        {
            panel2.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 3";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 4";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 5";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 6";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 7";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            panel2.Visible = true;
            label2.Visible = true;
            label3.Visible = true;
            label2.Text = "Checkpoint 8";
            label3.Text = "Особенности: \n\n Стенд питья  \n Медицинский пункт";
        }
    }
}
